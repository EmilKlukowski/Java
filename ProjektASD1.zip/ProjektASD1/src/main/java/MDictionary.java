/**
 * !!! Podlegać modyfikacji mogę jedynie elementy oznaczone to do. !!!
 */

import org.javatuples.Pair;

import java.io.*;
import java.util.Arrays;


public class MDictionary {
	private Pair<String, Integer>[] dictionary;
	private int size = Rozmiar.MAX_ELEM;

	public MDictionary() {
		this.dictionary = new Pair[size];
	}

	/**
	 * Opróżnia słownik i zwalnia pamięć po kolekcjach słownikowych
	 * // <remarks>Metoda przydatna na zakończenie Dictu lub przed ponownym załadowaniem</remarks>
	 **/
	public void Empty() {
		File folder = new File("indices");

		for (File file : folder.listFiles())
			file.delete();
	}

	/**
	 * Metoda zeruje liczbę wystąpień pojęć w słowniku
	 **/
	public void Reset() {
		for (int i = 0; i < dictionary.length; i++) {
			if (dictionary[i] != null) {
				Pair<String, Integer> resetPair = new Pair<>(dictionary[i].getValue0(), 0);
				dictionary[i] = resetPair;
			}
		}
	}

	/**
	 * Dodanie pojęcia do słownika na podstawie słowa i numeru klucza haszowego
	 **/
	private int Add(String W, int h) {
		// to do
		int index = h % size;

		if (dictionary[index] == null) {
			this.dictionary[index] = new Pair<>(W, 0);
		} else {
			while (dictionary[index++] == null) {
				this.dictionary[index] = new Pair<>(W, 0);
			}
		}

		return index;
	}

	/**
	 * /// Dodanie pojęcia do słownika na podstawie słowa
	 **/
	public int Add(String W) {
		// to do
		//return Add("null", -1);
		return Add(W, Haszuj(W));
	}

	/**
	 * Podaje klucz dla danego słowa
	 **/
	private int Haszuj(String W) {
		int hash = 0;
		char[] charsOfString = W.toCharArray();

		for (int i = 0; i < W.length(); i++) {
			hash = (hash * 31 + charsOfString[i]) & 0x7FFFFFFF;
		}

		return hash;
	}

	/**
	 * Metoda zwraca numer słowa lub 0 i zwiększa liczbę wystąpień
	 **/
	private int Find(String W, int h) {
		// to do
		int idx = h % size;

		if (dictionary[idx] != null) {
			if (dictionary[idx].getValue0().equals(W)) {
				int count = dictionary[idx].getValue1();
				count++;
				Pair<String, Integer> modifiedPair = new Pair<>(dictionary[idx].getValue0(), count);
				dictionary[idx] = modifiedPair;
				return count;
			}
		}

		return 0;
	}

	/**
	 * Metoda zwraca numer słowa lub 0 i zwiększa liczbę wystąpień o n
	 **/
	public int FindAndAdd(String W, int n) {
		// to do
		if (Find(W) != 0) {
			int idx = Haszuj(W) % size;
			int count = dictionary[idx].getValue1();

			Pair<String, Integer> modifiedPair = new Pair<>(dictionary[idx].getValue0(), count + n - 1);
			dictionary[idx] = modifiedPair;

		}

		return 0;
	}

	/**
	 * <summary>
	 * Metoda zwraca numer słowa lub 0 i zwiększa liczbę wystąpień
	 **/
	public int Find(String W) {
		// to do
		return Find(W, Haszuj(W));
	}

	/**
	 * Zwraca słowa w słowniku
	 */
	public String[] getWords() {
		String[] words;
		int tabSize = 0;

		for (int i = 0; i < dictionary.length; i++) {
			if (this.dictionary[i] != null) {
				tabSize++;
			}
		}

		words = new String[tabSize];
		tabSize = 0;

		for (int i = 0; i < dictionary.length; i++) {
			if (this.dictionary[i] != null) {
				words[tabSize++] = this.dictionary[i].getValue0();
			}
		}

		return words;
	}

	/**
	 * Zwraca słowa, które wystąpiły w dokumencie
	 *
	 * @return
	 */
	public String[] getAppearedWords() {
		int sum = 0;
		String[] appearedWords = new String[Rozmiar.MAX_ELEM];
		int j = 0;

		for (int i = 0; i < dictionary.length; i++) {
			if (dictionary[i] != null) {
				if (dictionary[i].getValue1() != 0) {
					appearedWords[j] = dictionary[i].getValue0();
					j++;
				}
			}
		}


		return Arrays.copyOf(appearedWords, j);
	}


	/**
	 * Zwraca pojęcia, które wystąpiły oraz liczba wystąpień
	 *
	 * @return
	 */
	public Pair<String, Integer>[] getAppearedWordsWithCount() {
		String[] appearedWords = getAppearedWords();
		Pair<String, Integer>[] appearedWordsWithCount = new Pair[appearedWords.length];

		int i = 0;
		for (String appearedWord : appearedWords) {
			int idx = Haszuj(appearedWord) % size;


			if (dictionary[idx] != null) {
				int count = this.dictionary[idx].getValue1();
				appearedWordsWithCount[i] = new Pair<>(appearedWord, count);
				i++;

			}
		}


		return appearedWordsWithCount;
	}
}