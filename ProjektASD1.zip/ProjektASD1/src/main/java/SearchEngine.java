/**
 * !!! Podlegać modyfikacji mogę jedynie elementy oznaczone to do. !!!
 */

import org.javatuples.Pair;

import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;


public class SearchEngine {

	public String[] readFiles(String directory, MorfologyTool mt) {

		File folder = new File("files");
		HashSet<String> set = new HashSet<>();
		for (final File file : folder.listFiles()) {
			System.out.println(file.toString());
			String[] split = null;
			try {
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);
				String line;
				String text = "";
				while ((line = br.readLine()) != null)
					text += line + " ";
				br.close();
				split = text.split("[^a-zA-Z0-9ąćęłńóśżźĄĆŁŃÓĘŚŻŹ]+");
			} catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
			for (String s : split)
				if (toString().trim().length() > 1)
					set.add(mt.getConcept(s.toLowerCase()));
		}
		return set.toArray(String[]::new);
	}

	/**
	 * Czytanie pliku i jego rozbiór morfologiczny
	 *
	 * @param file
	 * @return
	 */
	public String[] readFile(File file) {
		String[] words = new String[500];
		try {
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			String line;
			int i = 0;

			while ((line = bufferedReader.readLine()) != null) {
				String[] ss = line.split("[^a-zA-Z0-9ąćęłńóśżźĄĆŁŃÓĘŚŻŹ]+");
				for (String s : ss) {
					if (!s.isEmpty()) {
						if (words[words.length - 1] != null) {
							words = fullArray(words);
							words[i] = s.toLowerCase();
							i++;
						} else {
							words[i] = s.toLowerCase();
							i++;
						}
					}
				}
			}
			bufferedReader.close();
			fileReader.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}


		int count = 0;
		for (int i = 0; i < words.length; i++) {
			if (words[i] != null) {
				count++;
			}
		}


		return Arrays.copyOf(words, count);
	}

	/**
	 * Czytanie profili i scalanie ich (merge). Metoda zwraca słownik główny
	 */
	public String[] readProfiles() {
		File profiles = new File("profiles");
		String[] slownik = new String[0];
		for (File file : profiles.listFiles()) {
			slownik = merge(readProfile(file.getPath()), slownik);
		}

		bubbleSort(slownik);
		return slownik;
	}


	private String[] merge(String[] t1, String[] t2) {
		String[] mergedArray = new String[t1.length + t2.length];

		for (int i = 0; i < t1.length; i++) {
			mergedArray[i] = t1[i];
		}

		for (int i = 0; i < t2.length; i++) {
			mergedArray[i + t1.length] = t2[i];
		}


		return mergedArray;
	}

	private static void bubbleSort(String[] array) {
		int n = array.length;
		boolean swapped;

		for (int i = 0; i < n - 1; i++) {
			swapped = false;

			for (int j = 0; j < n - 1 - i; j++) {
				if (array[j].compareToIgnoreCase(array[j + 1]) > 0) {
					String temp = array[j];
					array[j] = array[j + 1];
					array[j + 1] = temp;

					swapped = true;
				}
			}

			if (!swapped) {
				break;
			}
		}
	}

	public String[] fullArray(String[] oldArray) {
		int size = (int) (oldArray.length * 1.8);

		String[] newArray = new String[size];
		for (int i = 0; i < oldArray.length; i++) {
			newArray[i] = oldArray[i];
		}

		return newArray;
	}

	public String[] readProfile(String profileName) {
		String[] profileContent = new String[100];
		int countWhile = 0;

		try {
			FileReader fr = new FileReader(profileName);
			BufferedReader br = new BufferedReader(fr);

			String line;
			int lastIndex = 0;
			while ((line = br.readLine()) != null) {
				if (profileContent[profileContent.length - 1] != null) {
					profileContent = fullArray(profileContent);
					profileContent[lastIndex++] = line;
				} else {
					profileContent[lastIndex++] = line;
				}
				countWhile++;
			}

		} catch (IOException e) {
			throw new RuntimeException(e);
		}


		return Arrays.copyOf(profileContent, countWhile);
	}

	/**
	 * Tworzy plik indeksowy dla danego pliku tekstowego: w każdym wierszu jest pojęcie oraz jego liczba wystąpień w pliku
	 *
	 * @param fileEntry
	 * @param wordsL
	 */
	public void makeIndex(File fileEntry, Pair<String, Integer>[] wordsL) {
		// to do
		File idxFile = new File("indices/" + fileEntry.getName() + ".idx");
		try {
			FileWriter fw = new FileWriter(idxFile);

			for (Pair<String, Integer> entry : wordsL) {
				fw.write(entry.getValue0() + " " + entry.getValue1() + "\n");

				//Indeksy dla słów ----------------------------------
				updateIndex(fileEntry, entry.getValue0());
			}

			fw.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private void updateIndex(File fileEntry, String word) {
		try {
			File file = new File("indices/" + word + ".index");
			FileWriter fw = new FileWriter(file, true);
			fw.write(fileEntry.getName() + "\n");

			fw.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Zwraca pliki zawierające podane słowo
	 *
	 * @param word wyszukiwane słowo
	 * @return
	 */
	public String[] getDocsContainingWord(String word) {
		String[] files = new String[50];
		File file = new File("indices/" + word + ".index");
		int i = 0;
		try {

			if (file.getName().replaceFirst("[.][^.]+$", "").equals(word)) {
				String line;
				BufferedReader br = new BufferedReader(new FileReader(file));
				while ((line = br.readLine()) != null) {
					files[i] = line;
					i++;
				}
			}

		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return Arrays.copyOf(files, i);
	}

	public String[] getDocsContainingWords(String[] words) {
		//to do
		String[] docsContainingWords;
		int i = 0;
		try {
			MDictionary mDict = new MDictionary();

			BufferedReader br = new BufferedReader(new FileReader(new File("indices/" + words[0] + ".index")));
			String line;
			int length = 0;
			while ((line = br.readLine()) != null) {
				//plik indexowy dla slowa np. armia ma nazwy plikow wiec dodaje nazwy plikow;
				mDict.Add(line);
				length++; //ilosc linijek w pliku;
			}
			br.close();


			for (String s : words) {
				br = new BufferedReader(new FileReader(new File("indices/" + s + ".index")));
				while ((line = br.readLine()) != null) {
					mDict.Find(line);
				}
			}

			Pair<String, Integer>[] pairs = mDict.getAppearedWordsWithCount();
			docsContainingWords = new String[length];

			length = 0;
			i = 0;
			for (Pair<String, Integer> pair : pairs) {
				if (pair.getValue1() == words.length) {
					docsContainingWords[length++] = pair.getValue0();
					i++;
				}
			}

		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return Arrays.copyOf(docsContainingWords, i);
	}

	/**
	 * Zwraca n plików zawierających najwięcj poszukiwanych słów
	 *
	 * @param words
	 * @return
	 */
	public String[] getDocsWithMaxMatchingWords(String[] words, int n) {
		// to do

		MDictionary mDict = new MDictionary();
		for (String word : words) {
			try {
				File file = new File("indices/" + word + ".index");
				if (file.exists()) {
					BufferedReader br = new BufferedReader(new FileReader("indices/" + word + ".index"));
					String line;
					while ((line = br.readLine()) != null) {
						mDict.Add(line);
						mDict.Find(line);
					}
				}
			} catch (IOException e) {
				throw new RuntimeException(e);
			}


		}
		String[] docsWithMaxMatchingWords = new String[n];
		Pair<String, Integer>[] unSortedPairs = mDict.getAppearedWordsWithCount();
		Pair<String, Integer>[] sortedPairs = sort(unSortedPairs);

		for (int i = 0; i < docsWithMaxMatchingWords.length; i++) {
			docsWithMaxMatchingWords[i] = sortedPairs[i].getValue1() + ". " + sortedPairs[i].getValue0();
		}

		return docsWithMaxMatchingWords;
	}

	/**
	 * Zwrócenie n dokumentów z największą zgodnościa z wybranym profilem
	 *
	 * @param n
	 * @return
	 */
	public Pair<String, Double>[] getDocsClosestToProfile(int n, String profileName) {
		// to do
		String[] wordsInProfile = readProfile("profiles/" + profileName + ".txt");
		Pair<String, Double>[] allDocsClosestToProfile = new Pair[40];
		MDictionary mDict = new MDictionary();


		int profileLength = 0;
		for (String word : wordsInProfile) {
			mDict.Add(word);
			profileLength++;
		}

		File folder = new File("indices");
		int index = 0;
		for (File file : folder.listFiles()) {
			if (file.getName().contains(".txt")) {
				mDict.Reset();
				try {
					BufferedReader br = new BufferedReader(new FileReader(file));
					String line;
					while ((line = br.readLine()) != null) {
						String[] fullLine = line.split(" ");
						mDict.FindAndAdd(fullLine[0], Integer.parseInt(fullLine[1]));
					}

				} catch (IOException e) {
					throw new RuntimeException(e);
				}

				Pair<String, Integer>[] pairs = mDict.getAppearedWordsWithCount();


				double sum = 0;
				for (int i = 0; i < pairs.length; i++) {
					double logaritm = Math.log10(pairs[i].getValue1() + 1);
					sum += logaritm;
				}

				double compatibility = (sum / profileLength);

				BigDecimal bd = new BigDecimal(compatibility);
				compatibility = bd.setScale(3, RoundingMode.HALF_UP).doubleValue();


				Pair<String, Double> paraZgodnoscPlik = new Pair<>("files/" + file.getName().replaceFirst("[.][^.]+$", ""), compatibility);
				allDocsClosestToProfile[index++] = paraZgodnoscPlik;
			}
		}


		Pair<String, Double>[] sortedPairs = sortWithDoubles(Arrays.copyOf(allDocsClosestToProfile, index));


		return Arrays.copyOf(sortedPairs, n);
	}

//	private Pair<String, Integer>[] readIndex(File file, int count) {
//		// to do
//		return null;
//	}

	private Pair<String, Integer>[] sort(Pair<String, Integer>[] pairs) {
		// to do
		//bubble sort ulepszony

		for (int i = 0; i < pairs.length - 1; i++) {
			for (int j = 0; j < pairs.length - i - 1; j++) {
				if (pairs[j].getValue1() < pairs[j + 1].getValue1()) {

					Pair<String, Integer> temp = pairs[j];
					pairs[j] = pairs[j + 1];
					pairs[j + 1] = temp;
				}
			}
		}

		return pairs;
	}

	private Pair<String, Double>[] sortWithDoubles(Pair<String, Double>[] pairs) {
		// to do
		//bubble sort ulepszony

		for (int i = 0; i < pairs.length - 1; i++) {
			for (int j = 0; j < pairs.length - i - 1; j++) {
				if (pairs[j].getValue1() < pairs[j + 1].getValue1()) {

					Pair<String, Double> temp = pairs[j];
					pairs[j] = pairs[j + 1];
					pairs[j + 1] = temp;
				}
			}
		}

		return pairs;
	}
}