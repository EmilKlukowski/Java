/**
 * !!! Podlegać modyfikacji mogę jedynie elementy oznaczone to do. !!!
 */
public class Rozmiar
{
    public static int MAX_ELEM = 30_000;
    public static int MAX_WORD = 30_000;
    public static int PIERWSZA = 19137;
}