package zad1;

import javax.swing.text.html.Option;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Maybe<T> {
	T data;

	public Maybe(T data) {
		this.data = data;
	}

	public static <T> Maybe<T> of(T data) {
		return new Maybe<T>(data);
	}

	public void ifPresent(Consumer<T> cons) {
		if (this.data != null) {
			cons.accept(data);
		}
	}

	public <R> Maybe<R> map(Function<T, R> func) {
		if (this.data != null) {
			R result = func.apply(data);
			return new Maybe<>(result);
		} else {
			return new Maybe<>(null);
		}
	}

	public T get() throws NoSuchElementException {
		if (this.data != null) {
			return data;
		} else {
			throw new NoSuchElementException("maybe is empty");
		}
	}

	public boolean isPresent() {
		return this.data != null;
	}

	T orElse(T defVal) {
		if (this.data != null) {
			return data;
		} else {
			return defVal;
		}
	}

	Maybe<T> filter(Predicate<T> pred) {
		if(pred.test(this.data) || this.data==null){
			return new Maybe<>(data);
		}else {
			return new Maybe<>(null);
		}
	}

	@Override
	public String toString() {
		if(this.data!=null){
			return "Maybe has value " + this.data;
		}else {
			return "Maybe is empty";
		}
	}
}
