/**
 *
 *  @author Klukowski Emil S27944
 *
 */

package zad4;

import java.util.*;
import java.util.function.*;

public class XList<T> extends ArrayList<T> {
	public XList(T... elements) {
		super(Arrays.asList(elements));
	}

	public static <T> XList<T> of(T... elements) {
		return new XList<>(elements);
	}

	public static <T> XList<T> of(Collection<T> collection) {
		return (XList<T>) new XList<>(collection.toArray());
	}

	public static XList<String> charsOf(String str) {
		char[] charArray = str.toCharArray();
		String[] stringArray = new String[charArray.length];
		for (int i = 0; i < charArray.length; i++) {
			stringArray[i] = String.valueOf(charArray[i]);
		}
		return new XList<>(stringArray);
	}

	public static XList<String> tokensOf(String str, String... separators) {
		String separator = (separators.length > 0) ? separators[0] : "\\s+";
		String[] tokens = str.split(separator);
		return new XList<>(tokens);
	}

	public XList<T> union(T... elements) {
		this.addAll(Arrays.asList(elements));
		return this;
	}

	public XList<T> union(Collection<T> collection) {
		this.addAll(collection);
		return this;
	}

	public XList<T> diff(Collection<T> collection) {
		XList<T> result = (XList<T>) new XList<>(this);
		result.removeAll(collection);
		return result;
	}

	public XList<T> unique() {
		Set<T> uniqueSet = new LinkedHashSet<>(this);
		return (XList<T>) new XList<>(uniqueSet);
	}

	public XList<XList<T>> combine() {
		XList<XList<T>> result = new XList<>();
		for (T item : this) {
			for (T otherItem : this) {
				if (!item.equals(otherItem)) {
					XList<T> pair = new XList<>(item, otherItem);
					result.add(pair);
				}
			}
		}
		return result;
	}

	public XList<String> collect(Function<T, String> function) {
		XList<String> result = new XList<>();
		for (T item : this) {
			result.add(function.apply(item));
		}
		return result;
	}

	public String join(String separator) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < size(); i++) {
			if (i > 0) {
				sb.append(separator);
			}
			sb.append(get(i).toString());
		}
		return sb.toString();
	}

	public String join() {
		return join("");
	}

	public void forEachWithIndex(BiConsumer<T, Integer> consumer) {
		for (int i = 0; i < size(); i++) {
			consumer.accept(get(i), i);
		}
	}
}
