/**
 * @author Klukowski Emil S27944
 */

package zad2;


import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;

/*<--
 *  niezbędne importy
 */

public class Main {
	public static void main(String[] args) {

		Function<String, List<String>> flines = path -> {
			try {
				return Files.lines(Paths.get(path))
					.collect(Collectors.toList());
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		};

		Function<List<String>, String> join = list -> {
			StringBuilder toReturnString = new StringBuilder();
			for (String el : list) {
				toReturnString.append(el);
			}

			return toReturnString.toString();
		};

		Function<String, List<Integer>> collectInts = inputString -> {
			List<Integer> numbers = new ArrayList<>();

			Pattern pattern = Pattern.compile("\\d+");
			Matcher matcher = pattern.matcher(inputString);

			while (matcher.find()) {
				String numberStr = matcher.group();
				int number = Integer.parseInt(numberStr);
				numbers.add(number);
			}

			return numbers;

		};

		Function<List<Integer>, Integer> sum = list -> {
			int finalInt = 0;

			for (int el : list) {
				finalInt += el;
			}
			return finalInt;
		};
		/*<--
		 *  definicja operacji w postaci lambda-wyrażeń:
		 *  - flines - zwraca listę wierszy z pliku tekstowego
		 *  - join - łączy napisy z listy (zwraca napis połączonych ze sobą elementów listy napisów)
		 *  - collectInts - zwraca listę liczb całkowitych zawartych w napisie
		 *  - sum - zwraca sumę elmentów listy liczb całkowitych
		 */

		String fname = System.getProperty("user.home") + "/LamComFile.txt";
		InputConverter<String> fileConv = new InputConverter<>(fname);
		List<String> lines = fileConv.convertBy(flines);
		String text = fileConv.convertBy(flines, join);
		List<Integer> ints = fileConv.convertBy(flines, join, collectInts);
		Integer sumints = fileConv.convertBy(flines, join, collectInts, sum);

		System.out.println(lines);
		System.out.println(text);
		System.out.println(ints);
		System.out.println(sumints);

		List<String> arglist = Arrays.asList(args);
		InputConverter<List<String>> slistConv = new InputConverter<>(arglist);
		sumints = slistConv.convertBy(join, collectInts, sum);
		System.out.println(sumints);

	}
}

