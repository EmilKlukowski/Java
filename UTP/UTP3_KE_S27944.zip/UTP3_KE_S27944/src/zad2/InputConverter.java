package zad2;


import java.util.function.*;

public class InputConverter<T> {
	private T inputData;

	public InputConverter(T inputData) {
		this.inputData = inputData;
	}

	public <R> R convertBy(Function... functions) {
		Object inputObject = inputData;

		for (Function function : functions) {
			inputObject = function.apply(inputObject);
		}
		return (R) inputObject;
	}
}