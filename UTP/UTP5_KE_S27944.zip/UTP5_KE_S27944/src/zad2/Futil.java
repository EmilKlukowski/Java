package zad2;

import java.io.IOException;
import java.nio.charset.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

public class Futil {

	public static void processDir(String dirName, String resultFileName) {
		Path directory = Paths.get(dirName);
		Path resultFile = Paths.get(resultFileName);


		try {
			Files.write(resultFile, "".getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

			Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
					if (file.toString().endsWith(".txt")) {
						//odczyt
						List<String> lines = Files.readAllLines(file, Charset.forName("Cp1250"));
						//zapis
						Files.write(resultFile, lines, StandardCharsets.UTF_8, StandardOpenOption.APPEND);
					}

					return FileVisitResult.CONTINUE;
				}
			});
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
