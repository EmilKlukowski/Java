/**
 *
 *  @author Klukowski Emil S27944
 *
 */

package zad1;




import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.*;

public class Finder {
	public String fname;

	public Finder(String fname) {
		this.fname = fname;
	}

	public int getIfCount() {
		String pattern1 = "\\bif\\s*\\(";
//		String pattern2 = "//.*if";
//		String pattern3 = "/\\*.*?if.*?\\*/";
		int count = 0;


		try {
			BufferedReader br = new BufferedReader(new FileReader(fname));
			StringBuilder fileContent = new StringBuilder();
			String line;

			while ((line = br.readLine()) != null) {
				fileContent.append(line).append("\n");
			}

			Pattern p = Pattern.compile(pattern1);
			Matcher m = p.matcher(fileContent.toString());

			while (m.find()) {
				count++;
			}

		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return count;
	}

	public int getStringCount(String wordToFind) {
		int count = 0;

		//String pattern = "\\b" + Pattern.quote(wordToFind) + "\\b";

		try {
			BufferedReader br = new BufferedReader(new FileReader(fname));
			StringBuilder fileContent = new StringBuilder();
			String line;

			while ((line = br.readLine()) != null) {
				fileContent.append(line).append("\n");
			}

			Pattern p = Pattern.compile(wordToFind);
			Matcher m = p.matcher(fileContent.toString());

			while (m.find()) {
				count++;
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return count;
	}
}