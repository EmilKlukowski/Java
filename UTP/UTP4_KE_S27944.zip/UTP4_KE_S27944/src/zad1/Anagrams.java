/**
 *
 *  @author Klukowski Emil S27944
 *
 */

package zad1;


import java.io.*;
import java.util.*;

public class Anagrams {
	String filePath;
	public Anagrams(String filePath) {
		this.filePath = filePath;
	}

	public Iterable<? extends List<String>> getSortedByAnQty() {
		List<String> sortedWordList = new ArrayList<>();
		List<String> wordList = new ArrayList<>();
		Map<String, List<String>> anagramMap = new HashMap<>();

		try {
			File inFile = new File(filePath);
			Scanner scan = new Scanner(inFile);

			while(scan.hasNext()){
				String word = scan.next();
				wordList.add(word);
			}
			scan.close();
			//wczytane słowa z pliku


			for(String word : wordList){
				char[] letters = word.toCharArray();
				Arrays.sort(letters);
				String sortedWord = new String(letters);


				if (!anagramMap.containsKey(sortedWord)) {
					anagramMap.put(sortedWord, new ArrayList<>());
				}
				anagramMap.get(sortedWord).add(word);
			}
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}


		List<List<String>> sortedAnagrams = new ArrayList<>(anagramMap.values());

		sortedAnagrams.sort(Comparator
			.comparingInt((List<String> s) -> s.size())
			.reversed()
			.thenComparing(s -> s.get(0)));

		return sortedAnagrams;
	}

	public String getAnagramsFor(String wordToFind) {
		List<List<String>> anagramList = new ArrayList<>();

		for (List<String> anagramGroup : getSortedByAnQty()) {
			List<String> copy = new ArrayList<>(anagramGroup); // Tworzenie kopii grupy
			for (String anagram : anagramGroup) {
				if (anagram.equalsIgnoreCase(wordToFind)) {
					copy.remove(anagram); // Usuń podane słowo z kopii grupy anagramów
					anagramList.add(copy);
				}
			}
		}

		String outputString = wordToFind + ": ";

		for (int i = 0; i < anagramList.size(); i++) {
			List<String> element = anagramList.get(i);
			if (i > 0) {
				outputString += ", ";
			}
			outputString += element;
		}

		return outputString;
	}

}
