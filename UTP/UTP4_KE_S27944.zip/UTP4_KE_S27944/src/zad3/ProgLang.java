package zad3;


import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class ProgLang {
	String filePath;
	LinkedHashMap<String, List<String>> langMap;

	public ProgLang(String filePath) {
		this.filePath = filePath;
	}

	public LinkedHashMap<String, List<String>> getLangsMap() {
		LinkedHashMap<String, List<String>> langMap = new LinkedHashMap<>();

		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] parts = line.split("\t");

				List<String> names = new ArrayList<>(Arrays.asList(parts).subList(1, parts.length));

				langMap.put(parts[0], names);
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}


		this.langMap = langMap;
		return langMap;
	}

	public LinkedHashMap<String, List<String>> getProgsMap() {
		LinkedHashMap<String, List<String>> progsMap = new LinkedHashMap<>();


		for (List<String> internalList : this.langMap.values()) {
			for (int i = 0; i < internalList.size(); i++) {
				String name = internalList.get(i);
				List<String> languages = new ArrayList<>();
				for (Map.Entry<String, List<String>> entry: this.langMap.entrySet()) {
					if (entry.getValue().contains(name)) {
						languages.add(entry.getKey());
					}
				}
				progsMap.put(name, new ArrayList<>(languages));

				}
			}


		return progsMap;
	}

	public LinkedHashMap<String, List<String>> getProgsMapSortedByNumOfLangs() {

		return langMap.entrySet().stream()
			.sorted(Comparator.<Map.Entry<String, List<String>>, Integer>comparing(entry -> entry.getValue().size())
				.thenComparing(Map.Entry::getKey)) // Dodatkowe sortowanie alfabetyczne
			.collect(Collectors.toMap(
				Map.Entry::getKey,
				Map.Entry::getValue,
				(e1, e2) -> e1,
				LinkedHashMap::new
			));
	}

	public LinkedHashMap<String, List<String>> getLangsMapSortedByNumOfProgs() {
		return this.langMap;
	}

	public LinkedHashMap<String, List<String>> getProgsMapForNumOfLangsGreaterThan(int i) {
		return this.langMap;
	}
}
