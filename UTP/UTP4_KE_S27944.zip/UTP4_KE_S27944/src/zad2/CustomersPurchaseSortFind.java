/**
 *
 *  @author Klukowski Emil S27944
 *
 */

package zad2;


import java.io.*;
import java.sql.SQLOutput;
import java.util.*;

public class CustomersPurchaseSortFind {
	List<Purchase> purchaseList = new ArrayList<>();
	public void readFile(String fname) {

		try (BufferedReader br = new BufferedReader(new FileReader(fname))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] parts = line.split(";");
				Purchase purchase = new Purchase(parts[0], parts[1], parts[2], Double.parseDouble(parts[3]),Double.parseDouble(parts[4]));
				purchaseList.add(purchase);
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
//		for(Purchase p : purchaseList){
//			System.out.println(p.product);
//		}
	}


	public void showSortedBy(String sortMethod) {

		if(sortMethod.equals("Nazwiska")){
			System.out.println("Nazwiska");
			purchaseList.sort(Comparator.comparing((Purchase p) -> p.name)
				.thenComparingInt(p -> Integer.parseInt(p.id.substring(1))));

			for (Purchase p : purchaseList){
				System.out.println(p.id + ";" + p.name + ";" + p.product + ";" + p.price + ";" + p.quantity);
			}

			System.out.println();
		}

		if(sortMethod.equals("Koszty")){
			System.out.println("Koszty");
			purchaseList.sort(Comparator.comparingDouble(Purchase::cost)
				.reversed()
				.thenComparing((Purchase p) -> p.name));

			for (Purchase p : purchaseList){
				System.out.println(p.id + ";" + p.name + ";" + p.product + ";" + p.price + ";" + p.quantity + " " + "(koszt: " + p.cost() + ")");
			}
			//output: c00001;Kowalski Jan;bulka;2.0;100.0 (koszt: 200.0)
			System.out.println();
		}




	}

	public void showPurchaseFor(String id) {
		System.out.println("Klient " + id);
		for (Purchase p : purchaseList){
			if(id.equals(p.id)){
				System.out.println(p.id + ";" + p.name + ";" + p.product + ";" + p.price + ";" + p.quantity);
			}
		}
		System.out.println();
	}
}

