/**
 *
 *  @author Klukowski Emil S27944
 *
 */

package zad2;


public class Purchase {
	public String id;
	public String name;
	public String product;
	public double price;
	public double quantity;

	public Purchase(String id, String name, String product, double price, double quantity) {
		this.id = id;
		this.name = name;
		this.product = product;
		this.price = price;
		this.quantity = quantity;
	}

	public double cost(){
		return this.price * this.quantity;
	}

}
